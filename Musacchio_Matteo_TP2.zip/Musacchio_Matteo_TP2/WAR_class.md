
Las features presentes son:

*poss*: Número de posesiones de pelota en esa temporada.

*mp*: Número de minutos jugados en esa temporada.

*off_def* : Es una métrica del impacto que tuvo este jugador en la ofensa/defensa en esa temporada.

*pace_impact* : Es una métrica del impacto que tuvo este jugador en la velocidad de juego en esa temporada.
